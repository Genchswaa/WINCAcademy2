console.log('Hello Winc Academy');
    let name ='Gian';
    console.log(name);
    console.log(17 + 3);
    console.log(name + name);

    console.log(20 + 20);
    console.log(600 - 345);
    console.log(80 / 15);
    console.log(20 % 40);

    let leeftijd = 'tweeendertig';
    console.log(typeof leeftijd);