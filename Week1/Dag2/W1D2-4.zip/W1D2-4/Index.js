const age = 15;
if ( age > 18){
    console.log('Jij mag naar binnen, Welkom!')
} else if ( age < 18) {
    console.log('Helaas, nog even een paar jaar wachten. Tot ziens!')
};


const isFemale = false;
if ( isFemale == true){
    console.log('Veel plezier bij Ladies Night')
} else if ( isFemale == false){
    console.log('Het is Ladies Night, mannen helaas geen toegang.')
};


const driverStatus = 'bob'
if ( driverStatus == 'bob'){
    console.log('Jij mag rijden! Goede reis!')
} else {
    console.log('Jij mag niet rijden. Regel een chauffeur!')
};


