console.log("Hallo Winc Academy Studenten");
// Dit is een grote som!!
/*console.log(1230941 * 1823794);
console.log(637263 / 54);*/