const age = 24;
if ( age >= 18){
    console.log('Jij mag naar binnen, Welkom!')
} else if ( age < 18) {
    console.log('Helaas, nog even een paar jaar wachten. Tot ziens!')
};

if ( age >= 18 && age <= 25){
    console.log('Jij krijgt 50% korting!')
};

const name = 'Bram';
if ( name == 'Bram' || name == 'Sarah'){
    console.log('Gefeliciteerd! Jij krijgt een gratis biertje!')
};

const totalAmount = 99;
if ( totalAmount >= 25 && totalAmount <= 49){
    console.log('Yeah, Jij krijgt een portie bitterballen!')
} else if ( totalAmount >= 50 && totalAmount <= 99){
    console.log('ABAM, daar horen nachos bij')
} else if (totalAmount >= 100){
    console.log('Hey big spender!! Jij krijgt champagne!')
};
    
const isFemale = false;
if ( isFemale == true){
    console.log('Veel plezier bij Ladies Night')
} else if ( isFemale == false){
    console.log('Het is Ladies Night, mannen helaas geen toegang.')
};

const driverStatus = 'bob'
if ( driverStatus == 'bob'){
    console.log('Jij mag rijden! Goede reis!')
} else {
    console.log('Jij mag niet rijden. Regel een chauffeur!')
};


