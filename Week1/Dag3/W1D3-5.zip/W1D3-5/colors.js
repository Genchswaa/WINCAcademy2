let colors = ['yellow', 'blue', 'red', 'orange'];

colors.forEach(colors => {
    console.log(colors)
});

for (let i = 0; i < colors; i++){
    console.log(colors.length)
};
console.log(colors.length);

/* 3. Door array's te gebruiken wordt de code compacter en leesbaarder.
Vind de oude methode beter leesbaar. De nieuwe methode is vrij abstract
en dat vind ik nog lastig.

4. Niet aan toegekomen.