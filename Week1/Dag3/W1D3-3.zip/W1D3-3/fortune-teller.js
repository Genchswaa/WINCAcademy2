function tellFortune(numberChildren, partnersName, geographicLocation, jobTitle){
    
console.log('You will be a' + jobTitle + 'in' + geographicLocation + 'and married to' + partnersName + 'with' + numberChildren + 'Children');
};
tellFortune(3, 'Henk', 'Dordrecht', 'Teacher');
tellFortune(6, 'Maria', 'Rotterdam', 'Nurse');
tellFortune(2, 'Bob', 'Amsterdam', 'Truck driver');
