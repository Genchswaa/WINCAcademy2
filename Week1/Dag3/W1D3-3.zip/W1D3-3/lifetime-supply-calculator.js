function calculateSupply(leefTijd, amountDay){
    console.log('You will need' + amountDay + 'to last you until the old age of' + maxLeeftijd)
    amountDay = leefTijd * 365
    maxLeeftijd  = 80 * 365
};

console.log( calculateSupply(10) )