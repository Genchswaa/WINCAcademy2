alert('Welkom! ');

let name = prompt('Wat is je naam?', '');

alert('Hey ' + name);

alert('Voer een nummer in tussen de 0 en 25 om te beginnen met raden:');

let gok = prompt('Ik gok met het volgende nummer', '');


if (Math.random(i * 25) -0) {
    prompt('Dat is niet correct, opnieuw raden aub')
} else if (gok === random){
    prompt('Gefeliciteerd, je hebt gewonnen')
} else {
    prompt('Dag,' + name)
};
