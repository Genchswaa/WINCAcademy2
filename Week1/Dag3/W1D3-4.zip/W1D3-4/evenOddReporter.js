let number = 2;
while (number < 20){
    console.log('Dit nummer is lager dan 20');
    number++;
if (number % 2 == 0){
    console.log('EVEN')}
    else{
        console.log ('ONEVEN')
    }
} ;
console.log('Dit nummer zit boven de 20');