const button = document.getElementById('mybutton');
    
    button.addEventListener('click', function(x){
        alert('BUTTON CLICKED');
    });


  
    const button2 = document.getElementById('mybutton2');
    const body = document.querySelector('red-background');
    mybutton2.addEventListener('click', function(){
        
        body.classlist.add('red-background')
    });

  //  mybutton2.style.background = 'green'
/*const button2 = document.getElementById('mybutton2');
button2.addEventListener('click', function(y){
        
        element.classlist.add('red-background',)
    });  */




/*Deze code werkt. Moet nog een chagecollor in.
const button2 = document.getElementById('mybutton2');
    button2.addEventListener('click', function(y){
        alert('Klikker');
    }); */














    
