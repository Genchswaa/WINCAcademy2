const button = document.getElementById('mybutton');

    button.addEventListener('click', function(x){
    
        console.log('BUTTON CLICKED');
    };

